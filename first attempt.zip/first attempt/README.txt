Robert Fairbrother
CDI College Calgary North Campus assignment1
2022-02-24
*I created a file named package.json for my source code
*I may have used some code in a tutorial video on youtube here: https://www.youtube.com/watch?v=-RCnNyD0L-s
*I may signed my name into the .json file using https://www.freecodecamp.org/news/json-comment-example-how-to-comment-in-json-files/
*i installed express for the application server and ejs 
*i installed nodemon to restart the server when I make changes and dotenv to install enviroment variables to configure the server 
*** I started over using this tutorial: https://www.youtube.com/watch?v=b91XgdyX-SM ***
*